************ReadMe.txt for ML A1 ************
****Submitted by Group 083 *******
**20CS60R60-Ravi Pratap Singh**
**20CS60R64-Sahil Jain**

There exits an i python notebook file naming "083_ML_A1_CODE.ipynb" . This could directly be opened in jupyter notebook
and see the ouputs at every steps mentioned in report. 
To execute code put the location of the file in 4th cell "covid = pd.read_csv("/IndiaCOVIDStatistics.csv") " after that every cell could be run independently . 
