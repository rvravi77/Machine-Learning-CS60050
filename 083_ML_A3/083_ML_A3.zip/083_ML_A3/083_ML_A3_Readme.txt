
************ReadMe.txt for ML A3 ************
****Submitted by Group 083 *******
**20CS60R60-Ravi Pratap Singh**
**20CS60R64-Sahil Jain**

This Code is also located at google colab : https://colab.research.google.com/drive/1eGIDOShTWVSueKXes9Gp_5_KqsJH_Y7J#scrollTo=N5p5bQ45XmdP
There exits an i python notebook file naming "083_ML_A3_code.ipynb" . This could directly be opened in jupyter notebook
and see the ouputs at every steps mentioned in report. 
The code reads the CSV file located in google drive .
The code could also read the CSV file from desired location in local system when cell #2 in both tasks is replaced from this line "data = pd.read_csv("/Train_C.csv")"
After Loading CSV file every cell could be run independently to see the desired results given in assignment.
